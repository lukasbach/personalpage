<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klausurstats";
$prefix = "klausurstats_";
?>