Setup Info
==========

Change the mysql connection information in the file "server/mysql_connection_info.php", then
run "server/mysql_setup.php" to create the required mysql tables.

You can then serve the files via an apache server.