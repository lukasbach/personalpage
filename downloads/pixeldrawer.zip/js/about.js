/*$(document).ready(function() {
    $()
    
    $("#slider").animate({
        width: '+=30px'
    }, 1000);
});*/